//
//  serialComDefs.h
//  libNTRIPClient
//
//  Created by RQ on 19/08/13.
//  Copyright (c) 2013 Aman Enterprises Inc. All rights reserved.
//

#ifndef libNTRIPClient_serialComDefs_h
#define libNTRIPClient_serialComDefs_h

// modem control status bits
#define MODEM_STAT_CTS  0x01
#define MODEM_STAT_RI   0x02
#define MODEM_STAT_DSR  0x04
#define MODEM_STAT_DCD  0x08

#define MODEM_STAT_RTS  0x01
#define MODEM_STAT_DTR  0x02

// defines for dataLen, parity, stop bits
#define SERIAL_DATABITS_7   0x07
#define SERIAL_DATABITS_8   0x08

#define STOPBITS_1          0x01	// 1 stop bit for all byte sizes
#define STOPBITS_2          0x02	// 2 stop bits for 6-8 bit byte

#define SERIAL_PARITY_NONE  0x00
#define SERIAL_PARITY_ODD   0x01
#define SERIAL_PARITY_EVEN  0x02


// defines for rxFlowControl, txFlowControl
// if not 'NONE' flow control is handled within the accessory
#define TXFLOW_NONE 0x00
#define TXFLOW_CTS  0x01
#define TXFLOW_DSR  0x02
#define TXFLOW_DCD  0x03
#define TXFLOW_XOFF 0x04

#define RXFLOW_NONE 0x00				// default state:  DTR=OFF & RTS=OFF
#define RXFLOW_XOFF 0x01				// default state:  DTR=OFF & RTS=OFF
#define RXFLOW_RTS  0x02				// default state:  DTR=OFF & RTS=ON
#define RXFLOW_DTR  0x03				// default state:  DTR=ON & RTS=OFF

// the default config settings...
#define DEFAULT_TXFLOW TXFLOW_NONE
#define DEFAULT_RXFLOW RXFLOW_NONE
#define DEFAULT_SERIAL_DATABITS SERIAL_DATABITS_8
#define DEFAULT_SERIAL_PARITY SERIAL_PARITY_NONE
#define DEFAULT_STOPBITS STOPBITS_1
#ifdef LOCATION
#define DEFAULT_BAUD	115200
#else
#define DEFAULT_BAUD	115200
#endif
#define DEFAULT_RXFORWARDTIME	100
#define DEFAULT_RXFORWARDCOUNT	16
#define DEFAULT_TXACKSETTING	0
#define DEFAULT_XON_CHAR	0
#define DEFAULT_XOFF_CHAR	0

enum
{
 	kMsrCts = 0x01,
	kMsrRi =  0x02,
 	kMsrDsr = 0x04,
 	kMsrDcd = 0x08,
    
};

enum {
	kRSC_StreamBufferSize = 8192,
	kRSC_MaxMessageDataLength = 230,
	kRSC_SerialReadBufferSize = 8192,
    kRsc_TxFifoSize = 128,
    kRsc_TxFifoSize_V = 2048,
	kRSC_NoPasscode = 0
};

typedef struct serialPortStatus {
    unsigned char
    txDiscard,                      // non-zero if tx data msg from App discarded
    rxOverrun,                      // non-zero if overrun error occurred
    rxParity,                       // non-zero if parity error occurred
    rxFrame,                        // non-zero if frame error occurred
    txAck,                          // ack when tx buffer becomes empty (sent only if txAxkSetting non-zero in config)
    msr,                            // 0-3 current modem status bits for CTS, DSR, DCD & RI, 4-7 previous modem status bits, MODEM_STAT_
    rtsDtrState,                    // 0-3 current modem status bits for RTS & DTR, 4-7 previous modem status bits, MODEM_STAT_
    rxFlowStat,                     // rx flow control off= 0 on = RXFLOW_RTS/DTR/XOFF
    txFlowStat,                     // rx flow control off= 0 on = TXFLOW_DCD/CTS/DSR/XOFF
    returnResponse;                 // Non-zero if returned in response to config or control
    // message with returnStatus requested (non-zero). If non-zero the
    // value will equal the returnStatus byte.
} serialPortStatus;


typedef struct serialPortConfig {
	unsigned char  baudLo,      // baud rate lo/hi up to 57600
    baudHi,
	dataLen,                    // SERIAL_DATABITS_ 7, 8
	parity,                     // SERIAL_PARITY_ NONE, ODD, EVEN
    stopBits,                   // STOPBITS_ 1, 2
    txFlowControl,              // TXFLOW_
    rxFlowControl,              // RXFLOW_
    xonChar,                    // XON/XOFF flow control chars if used
    xoffChar,
    // RX forwarding parameters:
	rxForwardingTimeout,        // forward rx data when idle timeout reached
    rxForwardCount,             // or received this many chars..
    txAckSetting,               // NON-zero if a txAck response is requested (sent when tx buffer becomes empty)
    returnStatus;               // NON-zero if a status response (to this config message) is requested
}serialPortConfig;


typedef struct serialPortControl {
    unsigned char txFlush,          // non-zero if tx buffer should be flushed
    rxFlush,                      // non-zero if rx buffer should be flushed
    setDtr,                       // change DTR state to..
    dtr,                          //   DTR state 1=On, 0=Off (ignored if setDtr == 0)
    setRts,                       // change RTS state to..
    rts,                          //   RTS state 1=On, 0=Off (ignored if setRts == 0)
    txBreak,                      // tx 'n' break characters
    returnStatus;                 // non-zero if a status response (to this control message) is requested
}serialPortControl;

typedef enum DataSizeType
{
	kDataSize7 = SERIAL_DATABITS_7,
	kDataSize8 = SERIAL_DATABITS_8
} DataSizeType;

typedef enum ParityType
{
	kParityNone = SERIAL_PARITY_NONE,
	kParityOdd = SERIAL_PARITY_ODD,
	kParityEven = SERIAL_PARITY_EVEN
} ParityType;

typedef enum StopBitsType
{
	kStopBits1 = STOPBITS_1,
	kStopBits2 = STOPBITS_2
} StopBitsType;

#endif